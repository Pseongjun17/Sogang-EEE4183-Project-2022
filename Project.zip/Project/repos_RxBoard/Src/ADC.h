#ifndef _ADC_H_
#define _ADC_H_

#include <stm32f10x.h>
#include <stdlib.h>
#include "GlobalParameters.h"

void init_temperature_ADC (int *Temp_addr);

#endif
